"""Vector API schemas package."""
