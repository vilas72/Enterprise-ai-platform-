# package: app.domain.exceptions
