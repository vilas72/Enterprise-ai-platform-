"""Vector store package."""
